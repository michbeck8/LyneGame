package api;

/**
 * Possible GridCell types.
 */
public enum CellType
{
  OPEN, MIDDLE, ENDPOINT, CROSSING
}
